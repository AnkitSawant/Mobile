package com.ct.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ct.employee.Employee;

@Controller
public class MyController {
	
	@RequestMapping("/")
	public String getHomePage() {
		return "index";
	}
	
	@RequestMapping("/add")
	public String add() {
		Employee employee = new Employee();
		return "add";
	}
	
	@RequestMapping("/searchById")
	public String searchById() {
		return "search";
	}
	@RequestMapping("/displayAll")
	public String displayAll() {
		return "display";
	}
}
