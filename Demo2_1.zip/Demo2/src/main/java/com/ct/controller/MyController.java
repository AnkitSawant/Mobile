package com.ct.controller;

import org.apache.catalina.connector.Request;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ct.employee.Employee;
import com.ct.mobilemanagementservice.service.IEmployeeService;

@Controller
public class MyController {
	
	@Autowired
	IEmployeeService employeeService;
	
	@RequestMapping("/")
	public String getHomePage() {
		return "index";
	}
	
	@RequestMapping("/add")
	public ModelAndView add() {
		ModelAndView mvc = new ModelAndView();
		mvc.addObject("employee", new Employee());
		mvc.setViewName("add");
		return mvc;
	}
	
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public String register(@ModelAttribute("employee") Employee employee) {
		System.out.println(employee);
		employeeService.addEmployee(employee);
		System.out.println("Added");
		return "index";
	}
	
	@RequestMapping("/searchById")
	public String searchById() {
		return "search";
	}
	@RequestMapping("/displayAll")
	public String displayAll() {
		return "display";
	}
}
