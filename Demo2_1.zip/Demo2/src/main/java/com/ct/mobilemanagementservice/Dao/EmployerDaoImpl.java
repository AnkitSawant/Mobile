package com.ct.mobilemanagementservice.Dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.ct.employee.Employee;

//import com.ct.mobilemanagementservice.mobile.Mobile;

@Component
public class EmployerDaoImpl implements IEmployeeDaO {

	private static Map<Integer,Employee> employeeList = new HashMap<Integer,Employee>();


	@Override
	public Collection displayAll() {
		return employeeList.values();

	}

	@Override
	public void addEmployee(Employee employee) {
		employeeList.put(employee.getEmployeeId(),employee);
		
	}

	@Override
	public Employee searchById(int empId) {
		if(employeeList.containsKey(empId)) {
			return employeeList.get(empId);
		}
		else {
			return null;
		}
	}

}
