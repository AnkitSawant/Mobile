package com.ct.mobilemanagementservice.Dao;

import java.util.*;

import com.ct.employee.Employee;
//import com.ct.mobilemanagementservice.mobile.Mobile;

public interface IEmployeeDaO {

	public void addEmployee(Employee employee);
	
	public Employee searchById(int empId);
	
	public Collection displayAll();
	
//	public String deleteMobile(int empId);
}
