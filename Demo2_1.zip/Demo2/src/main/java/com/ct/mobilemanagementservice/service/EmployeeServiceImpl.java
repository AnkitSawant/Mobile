package com.ct.mobilemanagementservice.service;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ct.employee.Employee;
import com.ct.mobilemanagementservice.Dao.EmployerDaoImpl;
import com.ct.mobilemanagementservice.Dao.IEmployeeDaO;
//import com.ct.mobilemanagementservice.Dao.*;
//import com.ct.mobilemanagementservice.mobile.Mobile;

@Component
public class EmployeeServiceImpl implements IEmployeeService {
	
	@Autowired
	private static IEmployeeDaO employeeDao;
	/*private static final List<String> brands = new ArrayList<String>() {{
		add("Samsung");
		add("Nokia");
		add("Redmi");
		add("Sony");
		add("Realme");
		add("Motorola");
		add("Lenovo");
		add("Oppo");
		add("Vivo");
	}};*/
	

	@Override
	public Collection displayAll() {
		return employeeDao.displayAll();

	}

	@Override
	public String addEmployee(Employee employee) {
		
		int empId = (int)(Math.random()*9000)+1000;
		employee.setEmployeeId(empId);
		employeeDao.addEmployee(employee);
		return null;
	}

	@Override
	public Employee searchById(int empId) {
		
		return employeeDao.searchById(empId);
	} 

}
