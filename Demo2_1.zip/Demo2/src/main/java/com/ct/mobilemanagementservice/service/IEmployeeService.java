package com.ct.mobilemanagementservice.service;

import java.util.*;

import com.ct.employee.Employee;
//import com.ct.mobilemanagementservice.mobile.Mobile;

public interface IEmployeeService {

	public String addEmployee(Employee m);
	
	public Employee searchById(int mobId);
	
	public Collection displayAll();
	
//	public String deleteMobile(int mobId);
	
}
