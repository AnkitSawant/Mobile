package com.ct.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.catalina.connector.Request;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ct.employee.Employee;
import com.ct.mobilemanagementservice.service.EmployeeServiceImpl;
import com.ct.mobilemanagementservice.service.IEmployeeService;

@Controller
public class MyController {
	
	@Autowired
	EmployeeServiceImpl employeeService;
	
	@RequestMapping("/")
	public String getHomePage() {
		return "index";
	}
	
	@RequestMapping("/add")
	public ModelAndView add() {
		ModelAndView mvc = new ModelAndView();
		mvc.addObject("employee", new Employee());
		mvc.setViewName("add");
		return mvc;
	}
	
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public String register(@ModelAttribute("employee") Employee employee) {
		employeeService.addEmployee(employee);
		System.out.println("Added");
		return "index";
	}
	
	@RequestMapping("/searchById")
	public String searchById() {
		return "search";
	}
	
	@RequestMapping(value="/search",method=RequestMethod.POST)
	public ModelAndView search(@RequestParam("id") Integer empId) {
		Employee employee = employeeService.searchById(empId);
		ModelAndView mvc = new ModelAndView();
		mvc.addObject("employee", employee);
		mvc.setViewName("index");
		return mvc;
	}
	@RequestMapping("/displayAll")
	public ModelAndView displayAll() {
		
		List<Employee> employeeList;
		employeeList = employeeService.displayAll();
		ModelAndView mvc = new ModelAndView();
		mvc.addObject("employeeList", employeeList);
		mvc.setViewName("display");
		return mvc;
	}
	@RequestMapping("/upload")
	public String upload() {
		return "upload";
	}
	@RequestMapping(value="/upload",method=RequestMethod.POST)
	public String fileUpload(HttpServletRequest request) {
		if(ServletFileUpload.isMultipartContent(request)){
            try {
                List<FileItem> multiparts = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);
                for(FileItem item : multiparts){
                    if(!item.isFormField()){
                        String name = new File(item.getName()).getName();
                        System.out.println("name "+name);
                        item.write(
                          new File("C:\\desktop" + File.separator + name));
                    }
                }

               //File uploaded successfully
               request.setAttribute("message", "File Uploaded Successfully");
            } catch (Exception ex) {
               request.setAttribute("message", "File Upload Failed due to " + ex);
            }
		}
            else{
                request.setAttribute("message",
                       "Sorry this Servlet only handles file upload request");
            }

		return "index";
	}
}
