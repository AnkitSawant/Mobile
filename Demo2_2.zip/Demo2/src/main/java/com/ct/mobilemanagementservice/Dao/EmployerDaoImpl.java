package com.ct.mobilemanagementservice.Dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.ct.employee.Employee;

//import com.ct.mobilemanagementservice.mobile.Mobile;

@Component
public class EmployerDaoImpl implements IEmployeeDaO {
	
	private JdbcTemplate jdbcTemplate;

	@Autowired
    public void setDataSource(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }
	
	private static Map<Integer,Employee> employeeList = new HashMap<Integer,Employee>();


	@Override
	public List<Employee> displayAll() {
		
		String query = "SELECT * FROM employee1";
		List<Employee> employeeList = (List<Employee>) jdbcTemplate.query(query, new BeanPropertyRowMapper(Employee.class));
		return employeeList;

	}

	@Override
	public boolean addEmployee(Employee employee) {
		
		String query = "INSERT INTO employee1 VALUES (?,?,?,?,?)";
		int status = jdbcTemplate.update(query, new Object[] {employee.getEmployeeId(),employee.getName(),employee.getDesignation(),employee.getEmail(),employee.getPassword()});
		if(status == 1) {
			return true;
		}
		else {
			return false;
		}
		
	}

	@Override
	public Employee searchById(int empId) {

		String query = "SELECT * FROM employee1 WHERE employeeId = ?";
		return (Employee) jdbcTemplate.queryForObject(query, new Object[] {empId}, new BeanPropertyRowMapper());
		
	}

}
