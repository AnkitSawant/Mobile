package com.ct.mobilemanagementservice.Dao;

import java.util.*;

import org.springframework.stereotype.Component;

import com.ct.employee.Employee;
//import com.ct.mobilemanagementservice.mobile.Mobile;

@Component
public interface IEmployeeDaO {

	public boolean addEmployee(Employee employee);
	
	public Employee searchById(int empId);
	
	public List<Employee> displayAll();
	
//	public String deleteMobile(int empId);
}
