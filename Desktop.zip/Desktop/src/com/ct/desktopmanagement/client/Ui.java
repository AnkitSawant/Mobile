package com.ct.desktopmanagement.client;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.ct.desktopmanagement.desktop.Desktop;
import com.ct.desktopmanagement.exception.DesktopException;
import com.ct.desktopmanagement.service.*;

public class Ui {
	
	private static DesktopServiceImpl ds = new DesktopServiceImpl();
	static Scanner scn = new Scanner(System.in);
	private static Desktop d = null;
	public static void main(String[] args) {
		
		int type;
		String username;
		String password;
		
		System.out.println("Enter type of login\n"
				+ "1. Admin\n"
				+ "2. User\n");
		
		type = scn.nextInt();
		if(type == 1) {
			System.out.println("Enter username and password");
			username = scn.next();
			password = scn.next();
			try {
				if(ds.checkIfAdmin(username,password)) {
					//System.out.println("Nice");
						displayAdminOptions();		
				}
				else {
					throw new DesktopException("Username and password does not match");
				}
			}
			catch(DesktopException d) {
				System.out.println(d.getMessage());
			}
			
		}
		else {
			System.out.println("Enter username and password");
			username = scn.next();
			password = scn.next();
			
			try {
				if(ds.checkIfUser(username,password)) {
					System.out.println("Good Boy");
					//displayAdminOptions();
				}
				else {
					throw new DesktopException("Username and password does not match");
				}
			}
			catch(DesktopException d) {
				System.out.println(d.getMessage());
			}
			
		}
		
		

	}

	private static void displayAdminOptions() throws DesktopException {
		
		int option;
		
		do {
			System.out.println("Welcome to Sawant Desktop shop");
			System.out.println("==============================");
			System.out.println("1. Add Desktop");
			System.out.println("2. Search Desktop by Id");
			System.out.println("3. Display all Desktops");
			System.out.println("4. Exit");
			
			option = scn.nextInt();
			switch(option) {
			
				case 1: {
						insertDesktop();
				}
				
				case 2: {
					searchById();
				}
			}
			
		}while(true);
		
	}

	private static void searchById() throws DesktopException {
		int desktopId;
		System.out.println("Enter Desktop id to be searched.");
		try {
			desktopId = scn.nextInt();
			d = ds.searchById(desktopId);
			
		}
		catch(InputMismatchException e) {
			throw new DesktopException("Enter valid Desktop id to be searched");
		}
		
		
		
	}

	private static void insertDesktop() throws DesktopException {
		
		String brandName;
		String description;
		int ramMemory;
		int internalStorage;
		float price;
		
		try {
			System.out.println("Enter the following information of the mobile");
			System.out.println("BrandName");
			brandName = scn.next();
			scn.nextLine();
			System.out.println("Description");
			description = scn.nextLine();
			System.out.println("Ram Memory");
			ramMemory = scn.nextInt();
			System.out.println("Internal Storage");
			internalStorage = scn.nextInt();
			System.out.println("Price");
			price = scn.nextFloat();
			
			d = new Desktop(brandName, description, ramMemory, internalStorage,price);
			ds.insertDesktop(d);
			System.out.println("Desktop inserted successfully");
		}
		catch(InputMismatchException e) {
			throw new DesktopException("Enter valid input");
		}
		
	}

}
