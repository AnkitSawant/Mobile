package com.ct.desktopmanagement.client;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.ct.desktopmanagement.desktop.Desktop;
import com.ct.desktopmanagement.exception.DesktopException;
import com.ct.desktopmanagement.service.*;

public class Ui {
	
	private static DesktopServiceImpl ds = new DesktopServiceImpl();
	static Scanner scn = new Scanner(System.in);
	private static Desktop d = null;
	public static void main(String[] args) {
		
		int type;
		String username, password;
		do {
			System.out.println("Enter type of login\n"
					+ "1. Admin\n"
					+ "2. User login\n"
					+ "3. User signup\n"
					+ "4. Exit");
			type = scn.nextInt();
			
			switch(type) {
				case 1:{
					try {
						System.out.println("Enter username");
						username = scn.next();
						System.out.println("Enter password");
						password = scn.next();
						if(ds.checkIfAdmin(username,password)) {
							displayAdminOptions();
							//System.out.println("Why");
						}
						else {
							throw new DesktopException("Username and password does not match");
						}
					}
					catch(DesktopException d) {
						System.out.println(d.getMessage());
					}
					break;
				}
				case 2:{
					try {
						System.out.println("Enter username");
						username = scn.next();
						System.out.println("Enter password");
						password = scn.next();
						if(ds.checkIfUser(username,password)) {
							displayUserOptions();
						}
						else {
							throw new DesktopException("Username and password does not match");
						}
					}
					catch(DesktopException d) {
						System.out.println(d.getMessage());
					}
					break;
				}
				case 3:{
					long number;
					int otp;
					System.out.println("Enter username");
					username = scn.next();
					System.out.println("Enter password");
					password = scn.next();
					System.out.println("Enter your number starting with 91");
					number = scn.nextLong();
					try {
						ds.sendotp(number);
						System.out.println("Enter OTP.");
						otp = scn.nextInt();
						ds.userSignup(username, password,otp);
						System.out.println("User added.");
					} catch (DesktopException e) {
						System.out.println(e.getMessage());
					}
					break;
				}
				case 4:{
					ds = null;
					scn.close();
					scn = null;
					if(d != null) {
						d = null;
					}
					System.exit(0);
					break;
				}
				default: {
					System.out.println("Please enter an option from above mentioned list");
				}
			}
		}while(true);

	}

	private static void displayUserOptions() throws DesktopException {
		
		int option;
		do {
			System.out.println("Welcome to Sawant Desktop shop\n"
					+ "==============================\n"
					+ "1. Display all Desktops\n"
					+ "2. Logout");			
			option = scn.nextInt();
			switch(option) {
				case 1:{
					displayAll();
					break;
				}
				case 2:{
					break;
				}
				default: {
					System.out.println("Please enter an option from above mentioned list");
				}
			}
			if(option == 2) {
				System.out.println("Logged out Successfully");
				break;
			}
		}while(true);
	}

	private static void displayAdminOptions() throws DesktopException {
		
		int option;
		do {
			System.out.println("Welcome to Sawant Desktop shop\n"
					+ "==============================\n"
					+ "1. Add Desktop\n"
					+ "2. Search Desktop by Id\n"
					+ "3. Display all Desktops\n"
					+ "4. Logout");
			option = scn.nextInt();
			switch(option) {
				case 1: {
					insertDesktop();
					//System.out.println("Here");
					break;
				}
				case 2: {
					searchById();
					break;
				}
				case 3: {
					displayAll();
					break;
				}
				case 4: {
					break;
				}
				default: {
					System.out.println("Please enter an option from above mentioned list");
				}
			}
			if(option == 4) {
				System.out.println("Logged out secceessfully");
				break;
			}
		}while(true);
	}

	private static void displayAll() throws DesktopException {
		List<Desktop> desktopList = null;
		Iterator<Desktop> itr = null;
		desktopList = ds.displayAll();
		itr = desktopList.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println("");
		itr = null;
		desktopList = null;
	}

	private static void searchById() throws DesktopException {
		int desktopId;
		System.out.println("Enter Desktop id to be searched.");
		try {
			desktopId = scn.nextInt();
			d = ds.searchById(desktopId);
			System.out.println("Desktop found");
			System.out.println(d);
		}
		catch(InputMismatchException e) {
			throw new DesktopException("Enter valid Desktop id to be searched");
		}
		
	}

	private static void insertDesktop() throws DesktopException {
		
		String brandName, description;
		int ramMemory, internalStorage;
		float price;
		try {
			System.out.println("Enter the following information of the mobile");
			System.out.println("BrandName");
			brandName = scn.next();
			scn.nextLine();
			System.out.println("Description");
			description = scn.nextLine();
			System.out.println("Ram Memory");
			ramMemory = scn.nextInt();
			System.out.println("Internal Storage");
			internalStorage = scn.nextInt();
			System.out.println("Price");
			price = scn.nextFloat();
			
			d = new Desktop(brandName, description, ramMemory, internalStorage,price);
			ds.insertDesktop(d);
			System.out.println("Desktop inserted successfully");
		}
		catch(InputMismatchException e) {
			throw new DesktopException("Enter valid input");
		}
		finally {
			if(d != null) {
				d = null;
			}
		}
	}
}
