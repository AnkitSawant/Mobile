package com.ct.desktopmanagement.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collection;
import java.util.Properties;

import com.ct.desktopmanagement.desktop.Desktop;
import com.ct.desktopmanagement.exception.DesktopException;

public class DesktopDaoImpl implements IDesktopDao{

	private static FileInputStream fis=null;
	static Properties prop=new Properties();
	
	public boolean checkIfAdmin(String username, String password) throws DesktopException {
		try {
			fis=new FileInputStream("C:\\Users\\ankits7\\Desktop\\java\\com\\Desktop\\Credentials\\admin.properties");
			prop.load(fis);
			if(! prop.containsKey(username)) {
				throw new DesktopException("User name does not exist");
			}
			else if(prop.containsKey(username) && !password.equals(prop.get(username))){
				throw new DesktopException("Incorrect password");
			}
			else if(prop.containsKey(username) && password.equals(prop.get(username))){
				return true;
			}
		} catch (FileNotFoundException e) {
			throw new DesktopException(e.getMessage());
		} catch (IOException e) {
			throw new DesktopException(e.getMessage());
		}
		System.out.println("No");
		return false;
	}
	@Override
	public void insertDesktop(Desktop d) {
	
		
	}

	@Override
	public Desktop searchById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection displayAll() {
		// TODO Auto-generated method stub
		return null;
	}
	public boolean checkIfUser(String username, String password) throws DesktopException {
		
		try {
			fis=new FileInputStream("C:\\Users\\ankits7\\Desktop\\java\\com\\Desktop\\Credentials\\user.properties");;
			prop.load(fis);
			if(! prop.containsKey(username)) {
				throw new DesktopException("User name does not exist");
			}
			else if(prop.containsKey(username) && !password.equals(prop.get(username))){
				throw new DesktopException("Incorrect password");
			}
			else if(prop.containsKey(username) && password.equals(prop.get(username))){
				return true;
			}
		} catch (FileNotFoundException e) {
			throw new DesktopException(e.getMessage());
		} catch (IOException e) {
			throw new DesktopException(e.getMessage());
		}
		return false;
	}

	
}
