package com.ct.desktopmanagement.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.ct.desktopmanagement.desktop.Desktop;
import com.ct.desktopmanagement.exception.DesktopException;
import com.ct.desktopmanagement.util.DbUtil;
import com.ct.desktopmanagement.util.IQueryMapper;

public class DesktopDaoImpl implements IDesktopDao{

	private static FileInputStream fis=null;
	private static FileOutputStream fos = null;
	static Properties prop = null;
	Connection connection = null;
	
	public boolean checkIfAdmin(String username, String password) throws DesktopException {
		try {
			//fis=new FileInputStream("C:\\Users\\ankits7\\Desktop\\java\\com\\Desktop\\Credentials\\admin.properties");
			fis=new FileInputStream("D:\\Ankit\\Java\\Desktop\\Credentials\\admin.properties");
			prop = new Properties();
			prop.load(fis);
			if(! prop.containsKey(username)) {
				throw new DesktopException("User name does not exist");
			}
			else if(prop.containsKey(username) && !password.equals(prop.get(username))){
				throw new DesktopException("Incorrect password");
			}
			else if(prop.containsKey(username) && password.equals(prop.get(username))){
				fis.close();
				return true;
			}
		} catch (FileNotFoundException e) {
			throw new DesktopException(e.getMessage());
		} catch (IOException e) {
			throw new DesktopException(e.getMessage());
		}
		finally {
			fis = null;
			prop = null;
		}
		return false;
	}
	@Override
	public void insertDesktop(Desktop d) throws DesktopException {
	
		connection = DbUtil.getDbConnection();
		try (PreparedStatement st = connection.prepareStatement(IQueryMapper.INSERT);){
			//PreparedStatement st = connection.prepareStatement(IQueryMapper.INSERT);
			st.setInt(1, d.getDesktopId());
			st.setString(2, d.getBrandName());
			st.setString(3, d.getDescription());
			st.setInt(4, d.getInternalStorage());
			st.setInt(5, d.getRamMemory());
			st.setFloat(6, d.getPrice());
			if(st.execute()) {
				throw new DesktopException("Failed to insert data. Please try again");
			}
		} catch (SQLException e) {
			throw new DesktopException("Data not found");
		}
		finally {
			DbUtil.closeConnection();
			try {
				connection.close();
				connection = null;
			} catch (SQLException e) {
				throw new DesktopException("Unable to close connection to Database");
			}
		}
	}

	@Override
	public Desktop searchById(int id) throws DesktopException {
		
		Desktop d = null;
		connection = DbUtil.getDbConnection();
		try (PreparedStatement st = connection.prepareStatement(IQueryMapper.RETRIEVAL_BY_ID);){
			st.setInt(1, id);
			ResultSet rs = st.executeQuery();
			if(rs.next()) {
				d = new Desktop();
				d.setDesktopId(rs.getInt(1));
				d.setBrandName(rs.getString(2));
				d.setDescription(rs.getString(3));
				d.setInternalStorage(rs.getInt(4));
				d.setRamMemory(rs.getInt(5));
				d.setPrice(rs.getFloat(6));
				return d;
			}
			else {
				throw new DesktopException("Desktop not found");
			}
		} catch (SQLException e) {
			throw new DesktopException("Data not found");
		}
		finally {
			DbUtil.closeConnection();
			try {
				connection.close();
				connection = null;
			} catch (SQLException e) {
				throw new DesktopException("Unable to close connection to Database");
			}
		}
	}

	@Override
	public List<Desktop> displayAll() throws DesktopException {
		
		List<Desktop> desktopList = new ArrayList<Desktop>();
		Desktop d = null;
		connection = DbUtil.getDbConnection();
		try (PreparedStatement st = connection.prepareStatement(IQueryMapper.RETRIEVE_ALL);){
			ResultSet rs = st.executeQuery();
			if(rs.next()) {
				do {
					d = new Desktop();
					d.setDesktopId(rs.getInt(1));
					d.setBrandName(rs.getString(2));
					d.setDescription(rs.getString(3));
					d.setInternalStorage(rs.getInt(4));
					d.setRamMemory(rs.getInt(5));
					d.setPrice(rs.getFloat(6));
					desktopList.add(d);
				}while(rs.next());
			}
			else {
				throw new DesktopException("No desktop found");
			}
		} catch (SQLException e) {
			throw new DesktopException("Data not found");
		}
		finally {
			DbUtil.closeConnection();
			try {
				connection.close();
				connection = null;
			} catch (SQLException e) {
				throw new DesktopException("Unable to close connection to Database");
			}
		}
		return desktopList;
	}
	public boolean checkIfUser(String username, String password) throws DesktopException {
		
		try {
			//fis=new FileInputStream("C:\\Users\\ankits7\\Desktop\\java\\com\\Desktop\\Credentials\\user.properties");
			fis=new FileInputStream("D:\\Ankit\\Java\\Desktop\\Credentials\\user.properties");
			prop = new Properties();
			prop.load(fis);
			if(! prop.containsKey(username)) {
				throw new DesktopException("User name does not exist");
			}
			else if(!password.equals(prop.get(username))){
				throw new DesktopException("Incorrect password");
			}
			else if(prop.containsKey(username) && password.equals(prop.get(username))){
				return true;
			}
		} catch (FileNotFoundException e) {
			throw new DesktopException(e.getMessage());
		} catch (IOException e) {
			throw new DesktopException(e.getMessage());
		}
		finally {
			if(fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					throw new DesktopException("Unable to close file.");
				}
				fis = null;
			}
			prop = null;
		}
		return false;
	}
	
	public boolean checkUserName(String username) throws DesktopException {
		
		try {
			fis=new FileInputStream("D:\\Ankit\\Java\\Desktop\\Credentials\\user.properties");
			prop = new Properties();
			prop.load(fis);
			if(prop.containsKey(username)) {
				return true;
			}
			else {
				return false;
			}
		} catch (FileNotFoundException e) {
			throw new DesktopException(e.getMessage());
		} catch (IOException e) {
			throw new DesktopException(e.getMessage());
		}
		finally {
			if(fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					throw new DesktopException("Unable to close file.");
				}
				fis = null;
			}
			prop = null;
		}
	}
	public void addUser(String username, String password) throws DesktopException {
		
		try {
			//fis=new FileInputStream("D:\\Ankit\\Java\\Desktop\\Credentials\\user.properties");
			fos = new FileOutputStream("D:\\Ankit\\Java\\Desktop\\Credentials\\user.properties",true);
			prop = new Properties();
			//prop.load(fis);
			prop.setProperty(username, password);
			prop.store(fos, null);
		} catch (FileNotFoundException e) {
			throw new DesktopException(e.getMessage());
		} catch (IOException e) {
			throw new DesktopException("Unable to add User.");
		}
		finally {
			if(fos != null) {
				try {
					fos.close();
				} catch (IOException e) {
					throw new DesktopException("Unable to close file.");
				}
				fos = null;
			}
			prop = null;
		}
	}
}
