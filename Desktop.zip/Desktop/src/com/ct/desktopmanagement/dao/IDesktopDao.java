package com.ct.desktopmanagement.dao;

import java.util.Collection;

import com.ct.desktopmanagement.desktop.Desktop;

public interface IDesktopDao {
	
	public void insertDesktop(Desktop d);
	
	public Desktop searchById(int id);
	
	public Collection displayAll();

}
