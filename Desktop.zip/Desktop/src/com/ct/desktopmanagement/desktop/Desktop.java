package com.ct.desktopmanagement.desktop;

public class Desktop {

	private int desktopId;
	private String brandName;
	private String description;
	private int ramMemory;
	private int internalStorage;
	private float price;
	
	public Desktop() {
			
	}
	
	public Desktop(String brandName, String description, int ramMemory, int internalStorage, float price) {
		this.brandName = brandName;
		this.description = description;
		this.ramMemory = ramMemory;
		this.internalStorage = internalStorage;
		this.price = price;
	}
	
	public int getDesktopId() {
		return desktopId;
	}

	public void setDesktopId(int desktopId) {
		this.desktopId = desktopId;
	}

	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getRamMemory() {
		return ramMemory;
	}
	public void setRamMemory(int ramMemory) {
		this.ramMemory = ramMemory;
	}
	public int getInternalStorage() {
		return internalStorage;
	}
	public void setInternalStorage(int internalStorage) {
		this.internalStorage = internalStorage;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Desktop [desktopId=" + desktopId + ", brandName=" + brandName + ", description=" + description
				+ ", ramMemory=" + ramMemory + ", internalStorage=" + internalStorage + ", price=" + price + "]";
	}

	
	
		
}
