package com.ct.desktopmanagement.exception;

public class DesktopException extends Exception{
	
	public DesktopException(){
		
	}
	
	public DesktopException(String s){
		super(s);
	}

}
