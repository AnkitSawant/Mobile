package com.ct.desktopmanagement.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.ct.desktopmanagement.dao.DesktopDaoImpl;
import com.ct.desktopmanagement.desktop.Desktop;
import com.ct.desktopmanagement.exception.DesktopException;

public class DesktopServiceImpl implements IDesktopService {

	private static DesktopDaoImpl dd = new DesktopDaoImpl();
	private static final List<String> brands = new ArrayList<String>() {{
		add("Samsung");
		add("Dell");
		add("Acer");
		add("Apple");
	}};
	
	public boolean checkIfAdmin(String username, String password) throws DesktopException {
		
		return dd.checkIfAdmin(username, password);
		
	}
	
	@Override
	public void insertDesktop(Desktop d) throws DesktopException {
		
		if(!brands.contains(d.getBrandName())) {
			throw new DesktopException("Brand name is invalid");
		}
		
		dd.insertDesktop(d);
		
	}

	@Override
	public Desktop searchById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection displayAll() {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean checkIfUser(String username, String password) throws DesktopException {
		
		return dd.checkIfUser(username, password);
	}

}
