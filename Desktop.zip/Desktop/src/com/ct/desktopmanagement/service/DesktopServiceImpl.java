package com.ct.desktopmanagement.service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import com.ct.desktopmanagement.dao.DesktopDaoImpl;
import com.ct.desktopmanagement.desktop.Desktop;
import com.ct.desktopmanagement.exception.DesktopException;

public class DesktopServiceImpl implements IDesktopService {

	private static DesktopDaoImpl dd = new DesktopDaoImpl();
	private static final List<String> brands = new ArrayList<String>() {{
		add("Samsung");
		add("Dell");
		add("Acer");
		add("Apple");
	}};
	private static int otp;
	public boolean checkIfAdmin(String username, String password) throws DesktopException {
		
		return dd.checkIfAdmin(username, password);
		
	}
	
	@Override
	public void insertDesktop(Desktop d) throws DesktopException {
		
		if(!brands.contains(d.getBrandName())) {
			throw new DesktopException("Brand name is invalid");
		}
		while(true) {
			d.setDesktopId((int)(Math.random()*9000)+1000);
			try {
				dd.searchById(d.getDesktopId());
			}
			catch(DesktopException de) {
				if(de.getMessage() == "Desktop not found") {
					break;
				}
				else {
					throw new DesktopException(de.getMessage());
				}
			}
		}
		dd.insertDesktop(d);
	}

	@Override
	public Desktop searchById(int id) throws DesktopException {

		return dd.searchById(id);
	}

	@Override
	public List<Desktop> displayAll() throws DesktopException {
		
		return dd.displayAll();
	}

	public boolean checkIfUser(String username, String password) throws DesktopException {
		
		return dd.checkIfUser(username, password);
	}

	public void userSignup(String username, String password, int otp) throws DesktopException {
		
		if(dd.checkUserName(username)) {
			throw new DesktopException("Username already exists.");
		}
		else if(this.otp == otp){
			dd.addUser(username,password);
		}
		else {
			throw new DesktopException("otp incorrect.");
		}
		
	}
	
	public void sendotp(long number) throws DesktopException {
		
		otp = (int)(Math.random()*9000)+1000;
		try{
			// Construct data
			String apiKey = "apikey=" + "WrOlzC4VrQ0-rH0627LzqLKd7O0DnYookOUP5Eg9xh";
			String message = "&message=" + otp;
			String sender = "&sender=" + "TXTLCL";
			String numbers = "&numbers=" + number;

			// Send data
			HttpURLConnection conn = (HttpURLConnection) new URL("https://api.textlocal.in/send/?").openConnection();
			String data = apiKey + numbers + message + sender;
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Length", Integer.toString(data.length()));
			conn.getOutputStream().write(data.getBytes("UTF-8"));
			final BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream())); 
			rd.close();
			conn = null;
		} catch (Exception e) {
			throw new DesktopException("Error in sending otp.");	
		}
	}

}
