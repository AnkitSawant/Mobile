package com.ct.desktopmanagement.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.ct.desktopmanagement.exception.*;

public class DbUtil {
	public static Connection con = null;
	private static FileInputStream fis=null;
	
	public static Connection getDbConnection() throws DesktopException {

		try {
			fis=new FileInputStream("D:\\Ankit\\Java\\Desktop\\Credentials\\desktopDbConfig.properties");
			Properties prop=new Properties();
			prop.load(fis);
			con = DriverManager.getConnection(prop.getProperty("url"),prop.getProperty("username"),prop.getProperty("password"));
			//con = DriverManager.getConnection("jdbc:mysql://localhost:3306/equipments","root","root");
		}
		catch (SQLException e) {
			throw new DesktopException("unable to connect to databse " + e.getMessage());
		} catch (FileNotFoundException e) {
			throw new DesktopException(e.getMessage());
		} catch (IOException e) {
			throw new DesktopException(e.getMessage());
		}
		finally {
			try {
				fis.close();
			} catch (IOException e) {
				throw new DesktopException("Unable to close DbConfig file.");
			}
			fis = null;
		}
		/*
		 * finally { if(con!=null) { try { //System.out.println("in finally");
		 * con.close(); con=null; } catch (SQLException e) { throw new
		 * DesktopException("unable to close the connection with DB :: "+e.getMessage())
		 * ; } } }
		 */
		return con;
	}
	
	public static void closeConnection() throws DesktopException {
		
		if(con!=null) { 
			try { 
					con.close(); 
					con=null; 
				} 
			catch (SQLException e) { 
				throw new DesktopException("unable to close the connection with DB :: "+e.getMessage()); 
				} 
		} 	 
	}
}
