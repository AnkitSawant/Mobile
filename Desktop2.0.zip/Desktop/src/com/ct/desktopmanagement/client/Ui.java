package com.ct.desktopmanagement.client;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.ct.desktopmanagement.desktop.Desktop;
import com.ct.desktopmanagement.exception.DesktopException;
import com.ct.desktopmanagement.service.*;

public class Ui {
	
	private static DesktopServiceImpl desktopService = new DesktopServiceImpl();
	static Scanner input = new Scanner(System.in);
	private static Desktop desktop = null;
	public static void main(String[] args) {
		
		int type=0;
		String username, password;
		do {
			System.out.println("Enter type of login\n"
					+ "1. Admin\n"
					+ "2. User login\n"
					+ "3. User signup\n"
					+ "4. Exit");
			try {
				type = input.nextInt();
				switch(type) {
					case 1:{
						System.out.println("Enter username");
						username = input.next();
						System.out.println("Enter password");
						password = input.next();
						if(desktopService.checkIfAdmin(username,password)) {
							displayAdminOptions();
						}
						else {
							throw new DesktopException("Username and password does not match");
						}
						break;
					}
					case 2:{
						System.out.println("Enter username");
						username = input.next();
						System.out.println("Enter password");
						password = input.next();
						if(desktopService.checkIfUser(username,password)) {
							displayUserOptions();
						}
						else {
							throw new DesktopException("Username and password does not match");
						}
						break;
					}
					case 3:{
						long number;
						int otp = 0000;
						System.out.println("Enter username");
						username = input.next();
						System.out.println("Enter password");
						password = input.next();
						/*System.out.println("Enter your number starting with 91");
						number = input.nextLong();
						ds.sendotp(number);
						System.out.println("Enter OTP.");
						otp = input.nextInt();*/
						desktopService.userSignup(username, password,otp);
						System.out.println("User added successfully.");
						break;
					}
					case 4:{
						desktopService = null;
						input.close();
						input = null;
						if(desktop != null) {
							desktop = null;
						}
						System.out.println("Exiting...");
						System.out.println("Thank you!");
						System.exit(0);
						break;
					}
					default: {
						System.out.println("Please enter an option from above mentioned list");
					}
				}
			}
			catch(InputMismatchException exception)
			{
				System.out.println("Please provide inputs in valid format.");
				input.nextLine();
			}
			catch(DesktopException desktopException) {
				System.out.println(desktopException.getMessage());
			}
		}while(true);

	}

	private static void displayUserOptions() throws DesktopException {
		
		int option=0;
		do {
			System.out.println("Welcome to Sawant Desktop shop\n"
					+ "==============================\n"
					+ "1. Display all Desktops\n"
					+ "2. Logout");
			try {
				option = input.nextInt();
			}
			catch(InputMismatchException e) {
				System.out.println("Please provide inputs in valid format.");
			}
			input.nextLine();
			switch(option) {
				case 1:{
					displayAll();
					break;
				}
				case 2:{
					break;
				}
				default: {
					System.out.println("Please enter an option from above mentioned list");
				}
			}
			if(option == 2) {
				System.out.println("Logged out Successfully");
				break;
			}
		}while(true);
	}

	private static void displayAdminOptions() throws DesktopException {
		
		int option=0;
		do {
			System.out.println("Welcome to Sawant Desktop shop\n"
					+ "==============================\n"
					+ "1. Add Desktop\n"
					+ "2. Search Desktop by Id\n"
					+ "3. Display all Desktops\n"
					+ "4. Logout");
			try {
				option = input.nextInt();
				switch(option) {
					case 1: {
						insertDesktop();
						break;
					}
					case 2: {
						searchById();
						break;
					}
					case 3: {
						displayAll();
						break;
					}
					case 4: {
						break;
					}
					default: {
						System.out.println("Please enter an option from above mentioned list");
					}
				}
			}
			catch(InputMismatchException e) {
				System.out.println("Please provide inputs in valid format.");
			}
			input.nextLine();
			if(option == 4) {
				System.out.println("Logged out secceessfully");
				break;
			}
		}while(true);
	}

	private static void displayAll() throws DesktopException {
		List<Desktop> desktopList = null;
		Iterator<Desktop> iterator = null;
		desktopList = desktopService.displayAll();
		iterator = desktopList.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		System.out.println("");
		iterator = null;
		desktopList = null;
	}

	private static void searchById() throws DesktopException, InputMismatchException {
		int desktopId;
		System.out.println("Enter Desktop id to be searched.");
		desktopId = input.nextInt();
		desktop = desktopService.searchById(desktopId);
		System.out.println("Desktop found");
		System.out.println(desktop);
		
	}

	private static void insertDesktop() throws DesktopException, InputMismatchException {
		
		String brandName, description;
		int ramMemory, internalStorage;
		float price;
		System.out.println("Enter the following information of the mobile");
		System.out.println("BrandName");
		brandName = input.next();
		input.nextLine();
		System.out.println("Description");
		description = input.nextLine();
		System.out.println("Ram Memory");
		ramMemory = input.nextInt();
		System.out.println("Internal Storage");
		internalStorage = input.nextInt();
		System.out.println("Price");
		price = input.nextFloat();
		
		desktop = new Desktop(brandName, description, ramMemory, internalStorage,price);
		desktopService.insertDesktop(desktop);
		System.out.println("Desktop inserted successfully");
		if(desktop != null) {
			desktop = null;
		}
	}
}
