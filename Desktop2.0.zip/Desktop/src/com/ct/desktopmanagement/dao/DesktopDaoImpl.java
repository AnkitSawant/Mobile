package com.ct.desktopmanagement.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.ct.desktopmanagement.desktop.Desktop;
import com.ct.desktopmanagement.exception.DesktopException;
import com.ct.desktopmanagement.util.DbUtil;
import com.ct.desktopmanagement.util.IQueryMapper;

public class DesktopDaoImpl implements IDesktopDao{

	private static FileInputStream fileInputStream=null;
	private static FileOutputStream fileOutputStream = null;
	static Properties property = null;
	Connection connection = null;
	
	public boolean checkIfAdmin(String username, String password) throws DesktopException {
		try {
			//fis=new FileInputStream("C:\\Users\\ankits7\\Desktop\\java\\com\\Desktop\\Credentials\\admin.properties");
			//fis=new FileInputStream("D:\\Ankit\\Java\\Desktop\\Credentials\\admin.properties");
			fileInputStream=new FileInputStream("C:\\New folder\\Desktop\\Credentials\\admin.properties");
			property = new Properties();
			property.load(fileInputStream);
			if(! property.containsKey(username)) {
				throw new DesktopException("User name does not exist");
			}
			else if(property.containsKey(username) && !password.equals(property.get(username))){
				throw new DesktopException("Incorrect password");
			}
			else if(property.containsKey(username) && password.equals(property.get(username))){
				fileInputStream.close();
				return true;
			}
		} catch (FileNotFoundException exception) {
			throw new DesktopException(exception.getMessage());
		} catch (IOException exception) {
			throw new DesktopException(exception.getMessage());
		}
		finally {
			fileInputStream = null;
			property = null;
		}
		return false;
	}
	@Override
	public void insertDesktop(Desktop d) throws DesktopException {
	
		connection = DbUtil.getDbConnection();
		try (PreparedStatement queryStatement = connection.prepareStatement(IQueryMapper.INSERT);){
			//PreparedStatement st = connection.prepareStatement(IQueryMapper.INSERT);
			queryStatement.setString(1, d.getBrandName());
			queryStatement.setString(2, d.getDescription());
			queryStatement.setInt(3, d.getInternalStorage());
			queryStatement.setInt(4, d.getRamMemory());
			queryStatement.setFloat(5, d.getPrice());
			if(queryStatement.executeUpdate() !=  1) {
				throw new DesktopException("Failed to insert data. Please try again");
			}
		} catch (SQLException exception) {
			throw new DesktopException("Failed to insert data. Please try again.");
		}
		finally {
			DbUtil.closeConnection();
			try {
				connection.close();
				connection = null;
			} catch (SQLException exception) {
				throw new DesktopException("Unable to close connection to Database");
			}
		}
	}

	@Override
	public Desktop searchById(int id) throws DesktopException {
		
		Desktop desktop = null;
		connection = DbUtil.getDbConnection();
		try (PreparedStatement queryStatement = connection.prepareStatement(IQueryMapper.RETRIEVAL_BY_ID);){
			queryStatement.setInt(1, id);
			ResultSet resultSet = queryStatement.executeQuery();
			if(resultSet.next()) {
				desktop = new Desktop();
				desktop.setDesktopId(resultSet.getInt(1));
				desktop.setBrandName(resultSet.getString(2));
				desktop.setDescription(resultSet.getString(3));
				desktop.setInternalStorage(resultSet.getInt(4));
				desktop.setRamMemory(resultSet.getInt(5));
				desktop.setPrice(resultSet.getFloat(6));
				return desktop;
			}
			else {
				throw new DesktopException("Desktop not found");
			}
		} catch (SQLException exception) {
			throw new DesktopException("Desktop not found");
		}
		finally {
			DbUtil.closeConnection();
			try {
				connection.close();
				connection = null;
			} catch (SQLException exception) {
				throw new DesktopException("Unable to close connection to Database");
			}
		}
	}

	@Override
	public List<Desktop> displayAll() throws DesktopException {
		
		List<Desktop> desktopList = new ArrayList<Desktop>();
		Desktop desktop = null;
		connection = DbUtil.getDbConnection();
		try (PreparedStatement queryStatement = connection.prepareStatement(IQueryMapper.RETRIEVE_ALL);){
			ResultSet resultSet = queryStatement.executeQuery();
			if(resultSet.next()) {
				do {
					desktop = new Desktop();
					desktop.setDesktopId(resultSet.getInt(1));
					desktop.setBrandName(resultSet.getString(2));
					desktop.setDescription(resultSet.getString(3));
					desktop.setInternalStorage(resultSet.getInt(4));
					desktop.setRamMemory(resultSet.getInt(5));
					desktop.setPrice(resultSet.getFloat(6));
					desktopList.add(desktop);
				}while(resultSet.next());
			}
			else {
				throw new DesktopException("No desktop found");
			}
		} catch (SQLException exception) {
			throw new DesktopException("Data not found");
		}
		finally {
			DbUtil.closeConnection();
			try {
				connection.close();
				connection = null;
			} catch (SQLException exception) {
				throw new DesktopException("Unable to close connection to Database");
			}
		}
		return desktopList;
	}
	public boolean checkIfUser(String username, String password) throws DesktopException {
		
		try {
			//fis=new FileInputStream("C:\\Users\\ankits7\\Desktop\\java\\com\\Desktop\\Credentials\\user.properties");
			//fis=new FileInputStream("D:\\Ankit\\Java\\Desktop\\Credentials\\user.properties");
			fileInputStream=new FileInputStream("C:\\New folder\\Desktop\\Credentials\\user.properties");
			property = new Properties();
			property.load(fileInputStream);
			if(!property.containsKey(username)) {
				throw new DesktopException("User name does not exist");
			}
			else if(!password.equals(property.get(username))){
				throw new DesktopException("Incorrect password");
			}
			else if(property.containsKey(username) && password.equals(property.get(username))){
				return true;
			}
		} catch (FileNotFoundException exception) {
			throw new DesktopException(exception.getMessage());
		} catch (IOException exception) {
			throw new DesktopException(exception.getMessage());
		}
		finally {
			if(fileInputStream != null) {
				try {
					fileInputStream.close();
				} catch (IOException exception) {
					throw new DesktopException("Unable to close file.");
				}
				fileInputStream = null;
			}
			property = null;
		}
		return false;
	}
	
	public boolean checkUserName(String username) throws DesktopException {
		
		try {
			//fis=new FileInputStream("D:\\Ankit\\Java\\Desktop\\Credentials\\user.properties");
			fileInputStream=new FileInputStream("C:\\New folder\\Desktop\\Credentials\\user.properties");
			property = new Properties();
			property.load(fileInputStream);
			if(property.containsKey(username)) {
				return true;
			}
			else {
				return false;
			}
		} catch (FileNotFoundException exception) {
			throw new DesktopException(exception.getMessage());
		} catch (IOException exception) {
			throw new DesktopException(exception.getMessage());
		}
		finally {
			if(fileInputStream != null) {
				try {
					fileInputStream.close();
				} catch (IOException exception) {
					throw new DesktopException("Unable to close file.");
				}
				fileInputStream = null;
			}
			property = null;
		}
	}
	public void addUser(String username, String password) throws DesktopException {
		
		try {
			//fis=new FileInputStream("D:\\Ankit\\Java\\Desktop\\Credentials\\user.properties");
			//fos = new FileOutputStream("D:\\Ankit\\Java\\Desktop\\Credentials\\user.properties",true);
			fileOutputStream = new FileOutputStream("C:\\New folder\\Desktop\\Credentials\\user.properties",true);
			property = new Properties();
			//prop.load(fis);
			property.setProperty(username, password);
			property.store(fileOutputStream, null);
		} catch (FileNotFoundException exception) {
			throw new DesktopException(exception.getMessage());
		} catch (IOException exception) {
			throw new DesktopException("Unable to add User.");
		}
		finally {
			if(fileOutputStream != null) {
				try {
					fileOutputStream.close();
				} catch (IOException exception) {
					throw new DesktopException("Unable to close file.");
				}
				fileOutputStream = null;
			}
			property = null;
		}
	}
}
