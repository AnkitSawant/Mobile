package com.ct.desktopmanagement.dao;

import java.util.List;

import com.ct.desktopmanagement.desktop.Desktop;
import com.ct.desktopmanagement.exception.DesktopException;

public interface IDesktopDao {
	
	public void insertDesktop(Desktop d) throws DesktopException;
	
	public Desktop searchById(int id) throws DesktopException;
	
	public List displayAll() throws DesktopException;

}
