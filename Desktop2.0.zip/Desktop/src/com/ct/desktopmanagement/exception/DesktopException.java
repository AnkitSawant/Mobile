package com.ct.desktopmanagement.exception;

public class DesktopException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DesktopException(){
		
	}
	
	public DesktopException(String message){
		super(message);
	}

}
