package com.ct.desktopmanagement.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.ct.desktopmanagement.exception.*;

public class DbUtil {
	public static Connection connection = null;
	private static FileInputStream fileInputStream=null;
	
	public static Connection getDbConnection() throws DesktopException {

		try {
			//fis=new FileInputStream("D:\\Ankit\\Java\\Desktop\\Credentials\\desktopDbConfig.properties");
			fileInputStream=new FileInputStream("C:\\New folder\\Desktop\\Credentials\\desktopDbConfig.properties");
			Properties property =new Properties();
			property.load(fileInputStream);
			connection = DriverManager.getConnection(property.getProperty("url"),property.getProperty("username"),property.getProperty("password"));
			//con = DriverManager.getConnection("jdbc:mysql://localhost:3306/equipments","root","root");
		}
		catch (SQLException exception) {
			throw new DesktopException("unable to connect to databse " + exception.getMessage());
		} catch (FileNotFoundException exception) {
			throw new DesktopException(exception.getMessage());
		} catch (IOException exception) {
			throw new DesktopException(exception.getMessage());
		}
		finally {
			try {
				fileInputStream.close();
			} catch (IOException exception) {
				throw new DesktopException("Unable to close DbConfig file.");
			}
			fileInputStream = null;
		}
		return connection;
	}
	
	public static void closeConnection() throws DesktopException {
		
		if(connection!=null) { 
			try { 
				connection.close(); 
				connection=null; 
				} 
			catch (SQLException exception) { 
				throw new DesktopException("unable to close the connection with DB :: "+exception.getMessage()); 
				} 
		} 	 
	}
}
