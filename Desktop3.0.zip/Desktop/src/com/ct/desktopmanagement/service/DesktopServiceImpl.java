package com.ct.desktopmanagement.service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import com.ct.desktopmanagement.dao.DesktopDaoImpl;
import com.ct.desktopmanagement.desktop.Desktop;
import com.ct.desktopmanagement.exception.DesktopException;

public class DesktopServiceImpl implements IDesktopService {

	private static DesktopDaoImpl desktopDao = new DesktopDaoImpl();
	@SuppressWarnings("serial")
	private static final List<String> brands = new ArrayList<String>() {{
		add("Samsung");
		add("Dell");
		add("Acer");
		add("Apple");
		add("Asus");
	}};
	private static int otp = 0000;
	public boolean checkIfAdmin(String username, String password) throws DesktopException {
		
		return desktopDao.checkIfAdmin(username, password);
		
	}
	
	@Override
	public void insertDesktop(Desktop desktop) throws DesktopException {
		
		if(!brands.contains(desktop.getBrandName())) {
			throw new DesktopException("Brand name is invalid. Please enter a valid brand name.");
		}
		
		desktopDao.insertDesktop(desktop);
	}

	@Override
	public Desktop searchById(int desktopId) throws DesktopException {

		return desktopDao.searchById(desktopId);
	}

	@Override
	public List<Desktop> displayAll() throws DesktopException {
		
		return desktopDao.displayAll();
	}

	public boolean checkIfUser(String username, String password) throws DesktopException {
		
		return desktopDao.checkIfUser(username, password);
	}

	public void userSignup(String username, String password, int otp) throws DesktopException {
		
		if(desktopDao.checkUserName(username)) {
			throw new DesktopException("Username already exists.");
		}
		else if(DesktopServiceImpl.otp == otp){
			desktopDao.addUser(username,password);
		}
		else {
			throw new DesktopException("otp is incorrect.");
		}
		
	}
	
	public void sendotp(long number) throws DesktopException {
		
		otp = (int)(Math.random()*9000)+1000;
		try{
			// Construct data
			String apiKey = "apikey=" + "WrOlzC4VrQ0-rH0627LzqLKd7O0DnYookOUP5Eg9xh";
			String message = "&message=" + otp;
			String sender = "&sender=" + "TXTLCL";
			String numbers = "&numbers=" + number;

			// Send data
			HttpURLConnection httpConnection = (HttpURLConnection) new URL("https://api.textlocal.in/send/?").openConnection();
			String data = apiKey + numbers + message + sender;
			httpConnection.setDoOutput(true);
			httpConnection.setRequestMethod("POST");
			httpConnection.setRequestProperty("Content-Length", Integer.toString(data.length()));
			httpConnection.getOutputStream().write(data.getBytes("UTF-8"));
			final BufferedReader reader = new BufferedReader(new InputStreamReader(httpConnection.getInputStream())); 
			reader.close();
			httpConnection = null;
		} catch (Exception exception) {
			throw new DesktopException("Unable to send otp. Please try again later or contact the administrator.");	
		}
	}

}
