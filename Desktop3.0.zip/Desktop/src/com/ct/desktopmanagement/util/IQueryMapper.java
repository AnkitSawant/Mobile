package com.ct.desktopmanagement.util;

public interface IQueryMapper {

	public static final String RETRIEVAL_BY_ID="SELECT * FROM desktop WHERE DesktopId=?";
	public static final String RETRIEVE_ALL="SELECT * FROM desktop";
	public static final String INSERT="INSERT INTO desktop (BrandName, Description, InternalStorage, RamMemory, Price) VALUES (?,?,?,?,?)";
	
}
