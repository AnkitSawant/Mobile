/**
 * 
 * Author: Ankit Sawant
 * Project: Desktop application
 * 
 *  
 * 
 **/

package com.ct.desktopmanagement.client;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.ct.desktopmanagement.dao.DesktopDaoImpl;
import com.ct.desktopmanagement.desktop.Desktop;
import com.ct.desktopmanagement.exception.DesktopException;
import com.ct.desktopmanagement.service.*;

public class Ui {

	static Logger log = Logger.getLogger(DesktopDaoImpl.class.getName()); 
	
	private static DesktopServiceImpl desktopService = new DesktopServiceImpl();
	static Scanner input = new Scanner(System.in);
	private static Desktop desktop = null;

	public static void main(String[] args) {

		int type = 0;
		String username, password;
		do {
			System.out.println(
					"Enter type of login\n" + "1. Admin\n" + "2. User login\n" + "3. User signup\n" + "4. Exit");
			try {
				type = input.nextInt();
				switch (type) {
				case 1: {
					log.info("Admin login");
					System.out.println("Enter username");
					username = input.next();
					System.out.println("Enter password");
					password = input.next();
					desktopService.checkIfAdmin(username, password);
					log.info("Admin logged in");
					displayAdminOptions();
					break;
				}
				case 2: {
					log.info("User login");
					System.out.println("Enter username");
					username = input.next();
					System.out.println("Enter password");
					password = input.next();
					desktopService.checkIfUser(username, password);
					log.info("User logged in.");
					displayUserOptions();
					break;
				}
				case 3: {
					log.info("User sign in.");
					long number;
					int otp = 0000;
					System.out.println("Enter username");
					username = input.next();
					System.out.println("Enter password");
					password = input.next();
					/*
					 * System.out.println("Enter your number starting with 91"); number =
					 * input.nextLong(); ds.sendotp(number); System.out.println("Enter OTP."); otp =
					 * input.nextInt();
					 */
					desktopService.userSignup(username, password, otp);
					log.info("User signed in.");
					System.out.println("User added successfully.");
					break;
				}
				case 4: {
					log.info("Quiting.");
					desktopService = null;
					input.close();
					input = null;
					if (desktop != null) {
						desktop = null;
					}
					System.out.println("Exiting...");
					System.out.println("Thank you!");
					System.exit(0);
					break;
				}
				default: {
					log.warn("Invalid option entered for login.");
					System.out.println("Please enter an option from above mentioned list");
					break;
				}
				}
			} catch (InputMismatchException exception) {
				log.error("Input mismatched for login option.");
				System.out.println("Please provide inputs in valid format.");
				input.nextLine();
			} catch (DesktopException desktopException) {
				System.out.println(desktopException.getMessage());
			}
		} while (true);

	}

	private static void displayUserOptions() {

		int option = 0, desktopId;
		do {
			System.out.println("Welcome to Sawant Desktop shop\n" + "==============================\n"
					+ "1. Display all Desktops\n" + "2. Buy a desktop\n" + "3. Logout");

			try {
				option = input.nextInt();
				input.nextLine();
				switch (option) {
				case 1: {
					log.info("Displaying all desktops");
					displayAll();
					break;
				}
				case 2: {
					log.info("Buying a desktop.");
					System.out.println("Enter the id of the desktop you want to buy.");
					desktopId = input.nextInt();
					buyDesktop(desktopId);
					break;
				}
				case 3: {
					log.info("User logout.");
					break;
				}
				default: {
					log.warn("Invalid option entered for login.");
					System.out.println("Please enter an option from above mentioned list");
					break;
				}
				}
			} catch (InputMismatchException exception) {
				log.error("Input mismatched for login option.");
				System.out.println("Please provide inputs in valid format.");
				input.nextLine();
			} catch (DesktopException desktopException) {
				System.out.println(desktopException.getMessage());
			}
			if (option == 3) {
				System.out.println("Logged out Successfully");
				break;
			}
		} while (true);
	}

	private static void buyDesktop(int desktopId) throws DesktopException {

		desktop = desktopService.searchById(desktopId);
		System.out.println(desktop);
		System.out.println("Congratulations you just bought a desktop");

	}

	private static void displayAdminOptions() {

		int option = 0;
		do {
			System.out.println("Welcome to Sawant Desktop shop\n" + "==============================\n"
					+ "1. Add Desktop\n" + "2. Search Desktop by Id\n" + "3. Display all Desktops\n" + "4. Logout");
			try {
				option = input.nextInt();
				switch (option) {
				case 1: {
					log.info("Adding a desktop.");
					insertDesktop();
					break;
				}
				case 2: {
					log.info("Searching a desktop by id.");
					searchById();
					break;
				}
				case 3: {
					log.info("Displaying all desktop for admin.");
					displayAll();
					break;
				}
				case 4: {
					log.info("Admin logout.");
					break;
				}
				default: {
					log.warn("Invalid option entered for login.");
					System.out.println("Please enter an option from above mentioned list");
					break;
				}
				}
			} catch (InputMismatchException exception) {
				log.error("Input mismatched for login option.");
				System.out.println("Please provide inputs in valid format.");
			} catch (DesktopException desktopException) {
				System.out.println(desktopException.getMessage());
			}
			input.nextLine();
			if (option == 4) {
				System.out.println("Logged out secceessfully");
				break;
			}
		} while (true);
	}

	private static void displayAll() throws DesktopException {
		List<Desktop> desktopList = null;
		Iterator<Desktop> iterator = null;
		desktopList = desktopService.displayAll();
		iterator = desktopList.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		System.out.println("");
		iterator = null;
		desktopList = null;
	}

	private static void searchById() throws DesktopException, InputMismatchException {
		int desktopId;
		System.out.println("Enter Desktop id to be searched.");
		desktopId = input.nextInt();
		desktop = desktopService.searchById(desktopId);
		System.out.println("Desktop found");
		System.out.println(desktop);

	}

	private static void insertDesktop() throws DesktopException, InputMismatchException {

		String brandName, description;
		int ramMemory, internalStorage;
		float price;
		System.out.println("Enter the following information of the desktop.");
		System.out.println("BrandName of desktop.");
		brandName = input.next();
		input.nextLine();
		System.out.println("Description of desktop.");
		description = input.nextLine();
		System.out.println("Ram Memory in gb of desktop.");
		ramMemory = input.nextInt();
		System.out.println("Internal Storage in gb of desktop.");
		internalStorage = input.nextInt();
		System.out.println("Price of desktop.");
		price = input.nextFloat();

		desktop = new Desktop(brandName, description, ramMemory, internalStorage, price);
		desktopService.insertDesktop(desktop);
		System.out.println("Desktop inserted successfully");
		if (desktop != null) {
			desktop = null;
		}
	}
}
