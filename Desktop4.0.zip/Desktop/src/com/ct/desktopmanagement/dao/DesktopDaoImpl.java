package com.ct.desktopmanagement.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.ct.desktopmanagement.desktop.Desktop;
import com.ct.desktopmanagement.exception.DesktopException;
import com.ct.desktopmanagement.util.DbUtil;
import com.ct.desktopmanagement.util.IQueryMapper;

public class DesktopDaoImpl implements IDesktopDao{

	static Logger log = Logger.getLogger(DesktopDaoImpl.class.getName());
	
	private static FileInputStream fileInputStream=null;
	private static FileOutputStream fileOutputStream = null;
	static Properties property = null;
	Connection connection = null;
	//private static String userPropertiesFile = "C:\\New folder\\Desktop\\Credentials\\user.properties";
	private static String userPropertiesFile = "C:\\Ankit\\Desktop\\Credentials\\user.properties";
	//private static String adminPropertiesFile = "C:\\New folder\\Desktop\\Credentials\\admin.properties";
	private static String adminPropertiesFile = "C:\\Ankit\\Desktop\\Credentials\\admin.properties";
	
	public boolean checkIfAdmin(String username, String password) throws DesktopException {
		try {
			//fis=new FileInputStream("C:\\Users\\ankits7\\Desktop\\java\\com\\Desktop\\Credentials\\admin.properties");
			//fis=new FileInputStream("D:\\Ankit\\Java\\Desktop\\Credentials\\admin.properties");
			fileInputStream=new FileInputStream(adminPropertiesFile);
			property = new Properties();
			property.load(fileInputStream);
			log.info("Admin properties file loaded.");
			
			if(! property.containsKey(username)) {
				log.debug("Invalid username");
				throw new DesktopException("User name does not exist");
			}
			else if(property.containsKey(username) && !password.equals(property.get(username))){
				log.debug("Incorrect password.");
				throw new DesktopException("Incorrect password");
			}
			else if(property.containsKey(username) && password.equals(property.get(username))){
				fileInputStream.close();
				log.info("Admin properties file clsoed.");
				return true;
			}
		} catch (FileNotFoundException exception) {
			log.error("Properties file not found.");
			throw new DesktopException("Unable to locate the server. Please try again later or contact the administrator.");
		} catch (IOException exception) {
			log.error("Cannot load properties file.");
			throw new DesktopException("Unable to retrieve data from the server. Please try again later or contact the administrator.");
		}
		finally {
			fileInputStream = null;
			property = null;
		}
		return false;
	}
	@Override
	public void insertDesktop(Desktop d) throws DesktopException {
	
		connection = DbUtil.getDbConnection();
		log.debug("Connectio to database established.");
		try (PreparedStatement queryStatement = connection.prepareStatement(IQueryMapper.INSERT);){
			//PreparedStatement st = connection.prepareStatement(IQueryMapper.INSERT);
			queryStatement.setString(1, d.getBrandName());
			queryStatement.setString(2, d.getDescription());
			queryStatement.setInt(3, d.getInternalStorage());
			queryStatement.setInt(4, d.getRamMemory());
			queryStatement.setFloat(5, d.getPrice());
			if(queryStatement.executeUpdate() !=  1) {
				throw new DesktopException("Failed to insert data. Please try again");
			}
			log.debug("Desktop inserted.");
		} catch (SQLException exception) {
			log.error("Failed to execute insert query.");
			throw new DesktopException("Failed to insert data in the server. Please try again.");
		}
		finally {
			DbUtil.closeConnection();
			try {
				connection.close();
				connection = null;
				log.debug("Connection to database closed.");
			} catch (SQLException exception) {
				log.error("Failed to close database connection.");
				throw new DesktopException("Unable to close connection to Database. Contact administrator.");
			}
		}
	}

	@Override
	public Desktop searchById(int id) throws DesktopException {
		
		Desktop desktop = null;
		connection = DbUtil.getDbConnection();
		log.debug("Connection to database established.");
		try (PreparedStatement queryStatement = connection.prepareStatement(IQueryMapper.RETRIEVAL_BY_ID);){
			queryStatement.setInt(1, id);
			ResultSet resultSet = queryStatement.executeQuery();
			log.debug("Search query executed.");
			if(resultSet.next()) {
				desktop = new Desktop();
				desktop.setDesktopId(resultSet.getInt(1));
				desktop.setBrandName(resultSet.getString(2));
				desktop.setDescription(resultSet.getString(3));
				desktop.setInternalStorage(resultSet.getInt(4));
				desktop.setRamMemory(resultSet.getInt(5));
				desktop.setPrice(resultSet.getFloat(6));
				return desktop;
			}
			else {
				throw new DesktopException("Desktop with id "+id+" does not exists.");
			}
		} catch (SQLException exception) {
			log.error("Failed to execute search query.");
			throw new DesktopException("Failed to retrive data from the server. Contact administrator.");
		}
		finally {
			DbUtil.closeConnection();
			try {
				connection.close();
				connection = null;
				log.debug("Database connection closed.");
			} catch (SQLException exception) {
				throw new DesktopException("Unable to close connection to Database. Contact administrator.");
			}
		}
	}

	@Override
	public List<Desktop> displayAll() throws DesktopException {
		
		List<Desktop> desktopList = new ArrayList<Desktop>();
		Desktop desktop = null;
		connection = DbUtil.getDbConnection();
		log.debug("Connection to database established.");
		try (PreparedStatement queryStatement = connection.prepareStatement(IQueryMapper.RETRIEVE_ALL);){
			ResultSet resultSet = queryStatement.executeQuery();
			log.debug("Retrieve all query executed.");
			if(resultSet.next()) {
				do {
					desktop = new Desktop();
					desktop.setDesktopId(resultSet.getInt(1));
					desktop.setBrandName(resultSet.getString(2));
					desktop.setDescription(resultSet.getString(3));
					desktop.setInternalStorage(resultSet.getInt(4));
					desktop.setRamMemory(resultSet.getInt(5));
					desktop.setPrice(resultSet.getFloat(6));
					desktopList.add(desktop);
				}while(resultSet.next());
			}
			else {
				throw new DesktopException("No desktop found available.");
			}
		} catch (SQLException exception) {
			log.error("Failed to execute retrieve all query.");
			throw new DesktopException("Failed to retrieve data from the server. Contact administrator.");
		}
		finally {
			DbUtil.closeConnection();
			try {
				connection.close();
				connection = null;
				log.debug("Databse connection closed.");
			} catch (SQLException exception) {
				log.error("Unable to close database connection.");
				throw new DesktopException("Unable to close connection to Database. Contact administrator.");
			}
		}
		return desktopList;
	}
	public boolean checkIfUser(String username, String password) throws DesktopException {
		
		try {
			//fis=new FileInputStream("C:\\Users\\ankits7\\Desktop\\java\\com\\Desktop\\Credentials\\user.properties");
			//fis=new FileInputStream("D:\\Ankit\\Java\\Desktop\\Credentials\\user.properties");
			fileInputStream=new FileInputStream(userPropertiesFile);
			property = new Properties();
			property.load(fileInputStream);
			log.debug("User properties file loaded");
			if(!property.containsKey(username)) {
				log.warn("Invalid username");
				throw new DesktopException("User name does not exist");
			}
			else if(!password.equals(property.get(username))){
				log.warn("Incorrect password");
				throw new DesktopException("Incorrect password");
			}
			else if(property.containsKey(username) && password.equals(property.get(username))){
				return true;
			}
		} catch (FileNotFoundException exception) {
			log.error("User properties file not found.");
			throw new DesktopException("Unable to locate the server. Please try again later or contact the administrator.");
		} catch (IOException exception) {
			log.error("Unable to open user properties fle.");
			throw new DesktopException("Unable to retrieve data from the server. Please try again later or contact the administrator.");
		}
		finally {
			if(fileInputStream != null) {
				try {
					fileInputStream.close();
					log.debug("User properties file closed.");
				} catch (IOException exception) {
					log.error("Unable to close user properties file.");
					throw new DesktopException("Unable to close the connection with server. Contact administrator.");
				}
				fileInputStream = null;
			}
			property = null;
		}
		return false;
	}
	
	public boolean checkUserName(String username) throws DesktopException {
		
		try {
			//fis=new FileInputStream("D:\\Ankit\\Java\\Desktop\\Credentials\\user.properties");
			fileInputStream=new FileInputStream(userPropertiesFile);
			property = new Properties();
			property.load(fileInputStream);
			log.debug("User properties file loaded");
			if(property.containsKey(username)) {
				return true;
			}
			else {
				return false;
			}
		} catch (FileNotFoundException exception) {
			log.error("User properties file not found.");
			throw new DesktopException("Unable to locate the server. Please try again later or contact the administrator.");
		} catch (IOException exception) {
			log.error("Unable to open user properties fle.");
			throw new DesktopException("Unable to retrieve data from the server. Please try again later or contact the administrator.");
		}
		finally {
			if(fileInputStream != null) {
				try {
					fileInputStream.close();
					log.debug("User properties file closed.");
				} catch (IOException exception) {
					log.error("Unable to close user properties file.");
					throw new DesktopException("Unable to close the connection with server. Contact administrator.");
				}
				fileInputStream = null;
			}
			property = null;
		}
	}
	public void addUser(String username, String password) throws DesktopException {
		
		try {
			//fis=new FileInputStream("D:\\Ankit\\Java\\Desktop\\Credentials\\user.properties");
			//fos = new FileOutputStream("D:\\Ankit\\Java\\Desktop\\Credentials\\user.properties",true);
			fileOutputStream = new FileOutputStream(userPropertiesFile,true);
			property = new Properties();
			log.debug("User properties file loaded");
			//prop.load(fis);
			property.setProperty(username, password);
			property.store(fileOutputStream, null);
			log.debug("New user added.");
		} catch (FileNotFoundException exception) {
			log.error("User properties file not found.");
			throw new DesktopException("Unable to locate the server. Please try again later or contact the administrator.");
		} catch (IOException exception) {
			log.error("Unable to open user properties fle.");
			throw new DesktopException("Unable to retrieve data from the server. Please try again later or contact the administrator.");
		}
		finally {
			if(fileOutputStream != null) {
				try {
					fileOutputStream.close();
					log.debug("User properties file closed.");
				} catch (IOException exception) {
					log.error("Unable to close user properties file.");
					throw new DesktopException("Unable to close the connection with server. Contact administrator.");
				}
				fileOutputStream = null;
			}
			property = null;
		}
	}
}
