package com.ct.desktopmanagement.service;

import java.util.List;

import com.ct.desktopmanagement.desktop.Desktop;
import com.ct.desktopmanagement.exception.DesktopException;

public interface IDesktopService {
	
	public void insertDesktop(Desktop d) throws DesktopException;
	
	public Desktop searchById(int id) throws DesktopException;
	
	public List<Desktop> displayAll() throws DesktopException;

}
