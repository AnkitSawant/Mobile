package com.ct.desktopmanagement.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.ct.desktopmanagement.exception.*;

public class DbUtil {
	public static Connection connection = null;
	private static FileInputStream fileInputStream=null;
	//private static String databaseConfigFile = "C:\\New folder\\Desktop\\Credentials\\desktopDbConfig.properties";
	private static String databaseConfigFile = "C:\\Ankit\\Desktop\\Credentials\\desktopDbConfig.properties";
	
	public static Connection getDbConnection() throws DesktopException {

		try {
			//fis=new FileInputStream("D:\\Ankit\\Java\\Desktop\\Credentials\\desktopDbConfig.properties");
			fileInputStream=new FileInputStream(databaseConfigFile);
			Properties property =new Properties();
			property.load(fileInputStream);
			connection = DriverManager.getConnection(property.getProperty("url"),property.getProperty("username"),property.getProperty("password"));
			//con = DriverManager.getConnection("jdbc:mysql://localhost:3306/equipments","root","root");
		}
		catch (SQLException exception) {
			throw new DesktopException("Unable to connect to database. Contact administrator.");
		} catch (FileNotFoundException exception) {
			throw new DesktopException("Database not found. Contact administrator.");
		} catch (IOException exception) {
			throw new DesktopException("Unable to connect to database. Contact administrator");
		}
		finally {
			try {
				fileInputStream.close();
			} catch (IOException exception) {
				throw new DesktopException("Unable to close DbConfig file.");
			}
			fileInputStream = null;
		}
		return connection;
	}
	
	public static void closeConnection() throws DesktopException {
		
		if(connection!=null) { 
			try { 
				connection.close(); 
				connection=null; 
				} 
			catch (SQLException exception) { 
				throw new DesktopException("Unable to close the connection with Database. Contact administrator."); 
				} 
		} 	 
	}
}
