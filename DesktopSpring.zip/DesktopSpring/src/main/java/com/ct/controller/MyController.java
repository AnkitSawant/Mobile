package com.ct.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ct.account.Login;

@Controller
public class MyController {

	@RequestMapping("/")
	public String getHomePage() {
		return "home";
	}
	
	@RequestMapping("/adminLogin")
	public ModelAndView getAdminLogin() {
		ModelAndView modelview = new ModelAndView();
		modelview.addObject("login",new Login());
		modelview.setViewName("adminLogin");
		return modelview;
	}
	
	
}
