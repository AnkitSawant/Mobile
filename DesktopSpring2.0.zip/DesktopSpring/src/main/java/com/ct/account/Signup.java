package com.ct.account;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="credentials", schema="equipments")
public class Signup {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int userId;
	@NotEmpty(message="Please enter First Name.")
	private String firstName;
	@NotEmpty(message="Please enter Last Name.")
	private String lastName;
	@NotNull(message="Please enter mobile number.")
	@Pattern(regexp = "(^$|[0-9]{10})", message="Mobile Number should contain only numbers and 10 digits.")
	private String mobileNumber;
	@NotEmpty(message="Please enter username.")
	private String username;
	@NotEmpty(message="Please enter an email.")
	@Email(message="Please enter a valid email.")
	private String email;
	@NotEmpty(message="Please enter a password")
	@Size(min=8, message="Password must be greater than 8 characters.")
	private String password;
	private final String role = "User";
	
	public Signup() {
	
	}

	public Signup(int userId, String firstName, String lastName, String mobileNumber, String username, String email,
			String password) {
		this.userId = userId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNumber = mobileNumber;
		this.username = username;
		this.email = email;
		this.password = password;
	}



	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	
}
