package com.ct.controller;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.ct.account.Login;
import com.ct.account.Signup;
import com.ct.desktopmanagement.desktop.Desktop;
import com.ct.desktopmanagement.exception.DesktopException;
import com.ct.desktopmanagement.service.DesktopServiceImpl;

@Controller
public class MyController {
	
	@Autowired
	DesktopServiceImpl desktopService;

	@RequestMapping("/")
	public ModelAndView getHomePage(HttpSession session) throws DesktopException {
		if(session.getAttribute("message") != null) session.removeAttribute("message");
		ModelAndView mv = new ModelAndView();
		List<Desktop> desktopList = desktopService.displayAll();
		mv.addObject("desktopList", desktopList);
		mv.setViewName("home");
		return mv;
	}
	
	@RequestMapping("/adminLogin")
	public ModelAndView getAdminLogin(HttpSession session) {
		if(session.getAttribute("message") != null) session.removeAttribute("message");
		Login login = new Login();
		ModelAndView modelview = new ModelAndView();
		modelview.addObject("login", login);
		modelview.setViewName("adminLogin");
		return modelview;
	}
	
	@RequestMapping("/login")
	public String loginCheck(@RequestBody @Valid @ModelAttribute("login") Login login, BindingResult br, HttpServletRequest request) throws DesktopException {
		
		//ModelAndView mv = new ModelAndView();
		if(!br.hasErrors()) {
			HttpSession session = request.getSession(true);
			if(desktopService.checkIfAdmin(login)) {
				session.setAttribute("username", login.getUsername());
				session.setAttribute("role", login.getRole());
				if("Admin".equals(login.getRole())) {
					return "adminpage";
					
				}
				else {
					//session.setAttribute("desktopList", desktopService.displayAll());
					return "user";
				}
			}
			else {
				session.setAttribute("message", "Invalid username and password.");
				return "adminLogin";
			}
		}
		else {
			return "adminLogin";
		}
	}
	
	@RequestMapping("userSignup")
	public ModelAndView getSignupPage() {
		Signup signup = new Signup();
		ModelAndView mv = new ModelAndView();
		mv.addObject("signup", signup);
		mv.setViewName("signup");
		return mv;
	}
	
	@RequestMapping("/signup")
	public String signup(@RequestBody @Valid @ModelAttribute("signup") Signup signup, BindingResult br, @RequestParam("confirmpassword") String pass, HttpSession session) {
		
		if(session.getAttribute("message") != null) session.removeAttribute("message");
		if(!br.hasErrors()) {
			if(signup.getPassword().equals(pass)){
				if(desktopService.checkIfUser(signup)) {
					desktopService.userSignup(signup);
					session.setAttribute("message", "User added successfully.");
					return "home";
				}
				else {
					session.setAttribute("message", "Username already exists.");
					return "signup";
				}
			}
			else {
				session.setAttribute("passmessage", "Passwords does not match.");
				return "signup";
			}
		}
		else {
			return "signup";
		}
	}
	
	@RequestMapping("/select")
	public ModelAndView getSelected(@RequestParam("Id") int desktopId, HttpServletRequest request) throws DesktopException {
		
		HttpSession session = request.getSession(false);
		ModelAndView mv = new ModelAndView();
		if(session.getAttribute("message") != null) session.removeAttribute("message");
		if(session.getAttribute("username") != null) {
			System.out.println(desktopId);
			mv.addObject("desktop", desktopService.searchById(desktopId));
			mv.setViewName("desktop");
		}
		else {
			mv.addObject("message", "Please Login first.");
			mv.setViewName("home");
		}
		return mv;
		
	}
	
	@RequestMapping("/addDesktop")
	public ModelAndView add(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		if(session.getAttribute("message") != null) session.removeAttribute("message");
		ModelAndView mv = new ModelAndView();
		System.out.println(session.getAttribute("username"));
		if(session.getAttribute("username") != null && "Admin".equals(session.getAttribute("role"))) {
			mv.addObject("desktop", new Desktop());
			mv.setViewName("add");
		}
		else {
			mv.addObject("message", "Please Login first.");
			mv.setViewName("home");
		}
		return mv;
	}
	
	public void upload(CommonsMultipartFile file, HttpSession session) {
		
		String path=session.getServletContext().getRealPath("/");  
		
        String filename=file.getOriginalFilename();  
          
        System.out.println(path+" "+filename);  
        try{  
	        byte barr[]=file.getBytes();  
	          
	        BufferedOutputStream bout=new BufferedOutputStream(  
	                 new FileOutputStream(path+"/Resources/images/"+filename));  
	        bout.write(barr);  
	        bout.flush();  
	        bout.close();  
          
        }catch(Exception e){System.out.println(e);}  
	}
	
	@RequestMapping(value="/addDesktop", method=RequestMethod.POST)
	public String addDesktop(@RequestParam("file") CommonsMultipartFile file, @Valid @ModelAttribute("desktop") Desktop desktop, BindingResult br, HttpSession session) throws DesktopException {
		System.out.println("Adding.");
		System.out.println(session.getAttribute("username"));
		if(session.getAttribute("message") != null) session.removeAttribute("message");
		if(!br.hasErrors()) {
			upload(file,session);
			desktop.setImage(file.getOriginalFilename());
			desktopService.insertDesktop(desktop);
			session.setAttribute("message", "Desktop added successfully.");
			return "adminpage";
		}
		else {
			session.setAttribute("message", "Unable to add Desktop.");
			return "add";
		}
	}
	
	@RequestMapping("/search")
	public String getSearchPage(HttpSession session) {
		if(session.getAttribute("message") != null) session.removeAttribute("message");
		if(session.getAttribute("username") != null && "Admin".equals(session.getAttribute("role"))) {
			return "search";
		}
		else {
			session.setAttribute("message", "Please Login first.");
			return "home";
		}
	}
	
	@RequestMapping("/searchById")
	public ModelAndView searchById(@RequestParam("id") int id, HttpServletRequest request) throws DesktopException {
		
		HttpSession session = request.getSession(false);
		if(session.getAttribute("message") != null) session.removeAttribute("message");
		ModelAndView mv = new ModelAndView();
		if(session.getAttribute("username") != null && "Admin".equals(session.getAttribute("role"))) {
			mv.addObject("desktop", desktopService.searchById(id));
			mv.setViewName("search");
		}
		else {
			mv.addObject("message", "Please Login first BHENCHOD.");
			mv.setViewName("home");
		}
		return mv;
	}
	
	@RequestMapping("/displayAll")
	public ModelAndView getDisplay(HttpServletRequest request) throws DesktopException {
		
		ModelAndView mv = new ModelAndView();
		HttpSession session = request.getSession(false);
		if(session.getAttribute("message") != null) session.removeAttribute("message");
		if(session.getAttribute("username") != null) {
			List<Desktop> desktopList = desktopService.displayAll();
			mv.addObject("desktopList", desktopList);
			mv.setViewName("display");
		}
		else {
			mv.addObject("message", "Please Login first.");
			mv.setViewName("home");
		}
		return mv;
		
	}
	
	@RequestMapping("/signout")
	public String signOut(HttpServletRequest request) {
		
		HttpSession session = request.getSession(false);
		if(session.getAttribute("message") != null) session.removeAttribute("message");
		session.removeAttribute("username");
		session.invalidate();
		return "home";
	}
}
