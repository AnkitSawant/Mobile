package com.ct.desktopmanagement.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import com.ct.account.Login;
import com.ct.account.Signup;
import com.ct.desktopmanagement.desktop.Desktop;
import com.ct.desktopmanagement.exception.DesktopException;
import com.ct.util.HibernateUtil;

public class DesktopDaoImpl implements IDesktopDao{
	
	@Autowired
	HibernateUtil hibernateUtil;
	
	public boolean checkIfAdmin(Login login) throws DesktopException {
		
		Session session = hibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		
		Criteria criteria = session.createCriteria(Signup.class);
		criteria.add(Restrictions.eq("username",login.getUsername()));
		criteria.add(Restrictions.eq("password",login.getPassword()));
		criteria.add(Restrictions.eq("role",login.getRole()));
		List<Login> loginList = criteria.list();
		session.close();
		if(loginList.isEmpty()) {
			return false;
		}
		else {
			return true;
		}
	}
	public void insertDesktop(Desktop desktop) throws DesktopException {
		
		Session session = hibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		Transaction transaction = session.getTransaction();
		
		session.save(desktop);
		transaction.commit();
		session.close();
	}

	public Desktop searchById(int id) throws DesktopException {
		
		Session session = hibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		
		Desktop desktop = (Desktop) session.get(Desktop.class, id);
		session.close();
		return desktop;
	}

	public List<Desktop> displayAll() throws DesktopException {
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		
		Criteria criteria = session.createCriteria(Desktop.class);
		List<Desktop> employeeList = criteria.list();
		session.close();
		return employeeList;
	}
	
	public boolean checkIfUser(Signup signup) {
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		
		Criteria criteria = session.createCriteria(Signup.class);
		criteria.add(Restrictions.eq("username", signup.getUsername()));
		return criteria.list().isEmpty();
	}
	public void addUser(Signup signup) {
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		Transaction transaction = session.getTransaction();
		
		session.save(signup);
		transaction.commit();
		session.close();
	}
}
