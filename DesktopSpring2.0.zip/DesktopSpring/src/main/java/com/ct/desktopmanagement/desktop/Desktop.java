package com.ct.desktopmanagement.desktop;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="desktop", schema="equipments")
public class Desktop{

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int desktopId;
	@NotEmpty(message="BrandName cannot be empty.")
	private String brandName;
	private String description;
	@NotNull(message="RamMemory cannot be empty.")
	private Integer ramMemory;
	@NotNull(message="Internal Storage cannot be empty.")
	private Integer internalStorage;
	@NotNull(message="Price cannot be empty.")
	private Float price;
	private String image;
	
	public Desktop() {
			
	}
	
	public Desktop(String brandName, String description, Integer ramMemory, Integer internalStorage, Float price) {
		this.brandName = brandName;
		this.description = description;
		this.ramMemory = ramMemory;
		this.internalStorage = internalStorage;
		this.price = price;
	}
	
	public Desktop(int desktopId, String brandName, String description, Integer ramMemory, Integer internalStorage,
			Float price, String image) {
		this.desktopId = desktopId;
		this.brandName = brandName;
		this.description = description;
		this.ramMemory = ramMemory;
		this.internalStorage = internalStorage;
		this.price = price;
		this.image = image;
	}

	public int getDesktopId() {
		return desktopId;
	}
	public void setDesktopId(int desktopId) {
		this.desktopId = desktopId;
	}
	public Integer getRamMemory() {
		return ramMemory;
	}
	public void setRamMemory(Integer ramMemory) {
		this.ramMemory = ramMemory;
	}
	public Integer getInternalStorage() {
		return internalStorage;
	}
	public void setInternalStorage(Integer internalStorage) {
		this.internalStorage = internalStorage;
	}
	public Float getPrice() {
		return price;
	}
	public void setPrice(Float price) {
		this.price = price;
	}
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}

	@Override
	public String toString() {
		return "Desktop [desktopId=" + desktopId + ", brandName=" + brandName + ", description=" + description
				+ ", ramMemory=" + ramMemory + ", internalStorage=" + internalStorage + ", price=" + price + "]";
	}		
}
