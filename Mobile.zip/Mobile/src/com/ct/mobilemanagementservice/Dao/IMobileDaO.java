package com.ct.mobilemanagementservice.Dao;

import java.util.*;

import com.ct.mobilemanagementservice.mobile.Mobile;

public interface IMobileDaO {

	public void addMobile(Mobile m);
	
	public Mobile searchMobile(int mobId);
	
	public Collection displayAll();
	
	public String deleteMobile(int mobId);
}
