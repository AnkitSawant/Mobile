package com.ct.mobilemanagementservice.Dao;

import java.util.ArrayList;
import java.util.*;
import java.util.List;

import com.ct.mobilemanagementservice.mobile.Mobile;

public class MobileDaoImpl implements IMobileDaO {

	private static Map<Integer,Mobile> mobiles = new HashMap();
	
	@Override
	public void addMobile(Mobile m) {
		mobiles.put(m.getMobId(),m);
	}

	@Override
	public Mobile searchMobile(int mobId) {
		if(mobiles.containsKey(mobId)) {
			return mobiles.get(mobId);
		}
		else {
			return null;
		}
	}

	@Override
	public Collection displayAll() {
		return mobiles.values();

	}

	@Override
	public String deleteMobile(int mobID) {
		if (mobiles.containsKey(mobID)) {
		mobiles.remove(mobID);
		return "Mobile deleted";
		}
		else
			return "Mobile does not exist";
	} 
}
