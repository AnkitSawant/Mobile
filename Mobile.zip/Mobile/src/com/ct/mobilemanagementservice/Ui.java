package com.ct.mobilemanagementservice;

import java.util.*;

import com.ct.mobilemanagementservice.mobile.Mobile;
import com.ct.mobilemanagementservice.service.*;



public class Ui {
	
	static Mobile m = null;
	static IMobileService ms = new MobileServiceImpl();
	static Collection displayMobiles = null;
	static Scanner scn = new Scanner(System.in);
	
	private static int mobId;
	private static String brandName;
	private static String description;
	private static int ramMemory;
	private static int internalStorage;
	private static float price;
	
	
	public static void addMobile() {
		
		System.out.println("Enter the following information of the mobile");
		System.out.println("Mobile Id");
		mobId = scn.nextInt();
		System.out.println("BrandName");
		brandName = scn.next();
		scn.nextLine();
		System.out.println("Description");
		description = scn.nextLine();
		System.out.println("Ram Memory");
		ramMemory = scn.nextInt();
		System.out.println("Internal Storage");
		internalStorage = scn.nextInt();
		System.out.println("Price");
		price = scn.nextFloat();
		
		m = new Mobile(mobId,brandName,description,ramMemory,internalStorage,price);
		System.out.println(ms.addMobile(m));
		
	}
	

	public static void searchMobile() {
		
		System.out.println("Enter the id of the mobile to be searched");
		mobId = scn.nextInt();
		m = ms.searchMobile(mobId);
		if(m == null) {
			System.out.println("Invalid id or Mobile not found");
		}
		else {
			System.out.println(m);
		}
		
	}
	
	public static void displayAll() {
		displayMobiles = ms.displayAll();
		System.out.println(displayMobiles);
	}
	
	public static void deleteMobile() {
		
		System.out.println("Enter ID to be deleted");
		int mobId = scn.nextInt();
		System.out.println(ms.deleteMobile(mobId));
		
	}
	
	public static void main(String[] args) {
		
		int option;
		
		do {
			System.out.println("Welcome to Sawant mobile shop");
			System.out.println("=============================");
			System.out.println("1. Add Mobile");
			System.out.println("2. Search Mobile by Id");
			System.out.println("3. Display all mobiles");
			System.out.println("4. Delete mobile");
			System.out.println("5. exit");
			
			option = scn.nextInt();
			
			switch(option) {
			
			case 1: {
				Ui.addMobile();
				break;
			}
			case 2: {
				Ui.searchMobile();
				break;
			}
			case 3: {
				Ui.displayAll();
				break;
			}
			case 4: {
				Ui.deleteMobile();
				break;
			}
			case 5: {
				System.out.println("Thank you");
				System.exit(0);
				break;
			}
			default: System.out.println("Please enter valid option from the provided menu");
			
			}
						
		}while(true);
		
		

	}

}
