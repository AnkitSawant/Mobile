package com.ct.mobilemanagementservice.mobile;

public class Mobile {

	private int mobId;
	private String brandName;
	private String description;
	private int ramMemory;
	private int internalStorage;
	private float price;
	
	public Mobile() {
		
	}
	
	public Mobile(int mobId, String brandName, String description, int ramMemory, int internalStorage, float price) {
		this.mobId = mobId;
		this.brandName = brandName;
		this.description = description;
		this.ramMemory = ramMemory;
		this.internalStorage = internalStorage;
		this.price = price;
	}

	public int getMobId() {
		return mobId;
	}
	public void setMobId(int mobId) {
		this.mobId = mobId;
	}
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getRamMemory() {
		return ramMemory;
	}
	public void setRamMemory(int ramMemory) {
		this.ramMemory = ramMemory;
	}
	public int getInternalStorage() {
		return internalStorage;
	}
	public void setInternalStorage(int internalStorage) {
		this.internalStorage = internalStorage;
	}
	public float getPrice() {
		return price;
	}
	
	public void setPrice(float price) {
		this.price = price;
	}
	
	@Override
	public String toString() {
		return "[ mobId=" + mobId + ", brandName=" + brandName + ", description=" + description + ", ramMemory="
				+ ramMemory + ", internalStorage=" + internalStorage + ", price=" + price + "]";
	}

	
	
	
	
}
