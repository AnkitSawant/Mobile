package com.ct.mobilemanagementservice.service;

import java.util.*;

import com.ct.mobilemanagementservice.mobile.Mobile;

public interface IMobileService {

	public String addMobile(Mobile m);
	
	public Mobile searchMobile(int mobId);
	
	public Collection displayAll();
	
	public String deleteMobile(int mobId);
	
}
