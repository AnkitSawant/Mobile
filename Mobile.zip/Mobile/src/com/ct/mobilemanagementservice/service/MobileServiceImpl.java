package com.ct.mobilemanagementservice.service;

import java.util.*;

import com.ct.mobilemanagementservice.Dao.*;
import com.ct.mobilemanagementservice.mobile.Mobile;

public class MobileServiceImpl implements IMobileService {
	
	private static Mobile m = null;
	private static IMobileDaO md = new MobileDaoImpl();
	private static final List<String> brands = new ArrayList<String>() {{
		add("Samsung");
		add("Nokia");
		add("Redmi");
		add("Sony");
		add("Realme");
		add("Motorola");
		add("Lenovo");
		add("Oppo");
		add("Vivo");
	}};
	
	@Override
	public String addMobile(Mobile m) {
		String mobId;
		this.m = m;
		mobId = Integer.toString(m.getMobId());
		
		if(mobId.length() != 8) {
			return "Id is invalid";
		}
		else if(!brands.contains(m.getBrandName())) {
			return "Brandname is not accepted";
		}
		else if(md.searchMobile(m.getMobId()) != null) {
			return "Mobile id already exists";
		}
		else {
			md.addMobile(m);
			return "Mobile added successfully";
		}
	}

	@Override
	public Mobile searchMobile(int mobId) {
		
		String mId;
		mId = Integer.toString(mobId);
		if(mId.length() != 8) {
			return null;
		}
		else {
			return md.searchMobile(mobId);
		}
	}

	@Override
	public Collection displayAll() {
		return md.displayAll();

	}

	@Override
	public String deleteMobile(int mobID)
	{
		return md.deleteMobile(mobID);
		
	} 

}
