package com.ct.Springmvc.SpringJdbc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ct.Springmvc.employeeDao.EmployeeDao;

public class App 
{
	/*@Autowired
	private EmployeeDao employeeDao;*/
	
    public static void main( String[] args )
    {
    	//App ap = new App();
        ApplicationContext ctx = new ClassPathXmlApplicationContext("springConfig.xml");
        EmployeeDao employeeDao = (EmployeeDao) ctx.getBean("edao");
        System.out.println(employeeDao.displayAll());
        //employeeDao.insert(new Employee(3, "Kammo", 12.12f, "Kalyan"));
        System.out.println(employeeDao.displayAll());
        System.out.println(employeeDao.searchById(2));
    }
}
