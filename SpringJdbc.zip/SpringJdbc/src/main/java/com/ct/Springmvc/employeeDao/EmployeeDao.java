package com.ct.Springmvc.employeeDao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.ct.Springmvc.employee.Employee;

@Component("edao")
public class EmployeeDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
/*	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {  
	    this.jdbcTemplate = jdbcTemplate;  
	} */
	
	public List<Employee> displayAll(){  
	    String query="SELECT * FROM employee";  
	    return jdbcTemplate.query(query, new BeanPropertyRowMapper(Employee.class));  
	}
	
	public boolean insert(Employee employee) {
		
		
		String query = "INSERT INTO employee VALUES (:id,:name,:salary,:city)";
		int status = jdbcTemplate.update(query, new Object[] {employee.getId(),employee.getName(),employee.getSalary(),employee.getCity()});
		if(status == 1) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public Employee searchById(int id) {
		
		String query = "SELECT * FROM employee WHERE id = ?";
		Employee employee= (Employee)jdbcTemplate.queryForObject(query, new Object[] {id}, new BeanPropertyRowMapper(Employee.class));
		return employee;
	}
	
}
